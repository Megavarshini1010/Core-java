
import java.util.Scanner;
//main class
public class UI {
    public static void main(String[] args) {
        //Get input from user 
        Scanner sn = new Scanner(System.in);
        Student st = new Student();//template class object
        boolean isWork =true;
        while(isWork){
            System.out.println("Enter any Choice : ");
			System.out.println("1 for create a New Student");
			System.out.println("2 for show Student");
			System.out.println("3 for modify a Student");
			System.out.println("0 for Exit");
			int key = sn.nextInt();

            if(key==1){
                System.out.println("Enter the Std id");
				int id = sn.nextInt();
				sn.nextLine();
				System.out.println("Enter the Student Name ");
				String name = sn.nextLine();
				System.out.println("Enter the Roll No ");
				int rollNo = sn.nextInt();
				System.out.println("Enter the Student Fees");
				double fees = sn.nextDouble();
                st =new Student(id,name,rollNo,fees);
            }
            else if(key ==2) {
				System.out.println(st);
			}else if(key == 3) {
		    	boolean isDone =true;
				while(isDone){
					System.out.println("Enter any Choice : ");
			System.out.println("1 for Change a Student Id ");
			System.out.println("2 for Change a Student Name ");
			System.out.println("3 for Change a Student RollNo ");
			System.out.println("4 for Change a Student Fees");
			System.out.println("0 for Exit");
			int set = sn.nextInt();
			if(set==1){
				System.out.println("Enter the Std id");
				int id = sn.nextInt();
				sn.nextLine();
				st.setId(id);
			}
			else if(set==2){
				System.out.println("Enter the Student Name ");
				String name = sn.nextLine();
				st.setName(name);
			}
			else if(set==3){
				System.out.println("Enter the Roll No ");
				int rollNo = sn.nextInt();
				st.setRollNo(rollNo);
			}
			else if(set==4){
				System.out.println("Enter the Student Fees");
				double fees = sn.nextDouble();
				st.setFees(fees);

			}else if(set == 0) {
				isDone = false;
			}
			
			else {
				System.out.println("Enter Corrct Option");
			}

				}
			}
				else if(key == 0) {
				isWork = false;
			}
			
			else {
				System.out.println("Enter Correct Option");
			}
    
    }
}
}
