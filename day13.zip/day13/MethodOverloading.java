public  class MethodOverloading{
    class Math{
        static int add(int a, int b)
        {
            return a+b;
        }
        static double add(double a, double b)
        {
            return a+b;
        }
    }
    class Main{
        public static void main(String[] args) {
            System.out.println(Math.add(75,84));
            System.out.println(Math.add(54.2,64.8));
        }
    }
}