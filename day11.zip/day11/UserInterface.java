package day11;

import java.util.Scanner;


public class UserInterface {
	
	public static void main(String[] args) {
		Employee emp1=new Employee();
		emp1.id=101;
		emp1.name="Akash";
		emp1.phoneNo=237475859;
		emp1.salary=4500.2;
		
		
		Employee emp2=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Employee 2 ID: ");
		emp2.id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter a Employee 2 Name: ");
		emp2.name=sc.nextLine();
		System.out.println("Enter a Employee 2 PhoneNo: ");
		emp2.phoneNo=sc.nextLong();
		System.out.println("Enter a Employee 2 Salary: ");
		emp2.salary=sc.nextDouble();
		System.out.println("Thankyou for entering employee details");
		
		Employee emp3=new Employee();
		emp3.id=103;
		emp3.name="Ishu";
		emp3.phoneNo=234374758;
		emp3.salary=4566.2;
		
	}

}
