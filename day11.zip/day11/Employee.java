package day11;

import java.util.Scanner;	

public class Employee {
	int id;
	String name;
	long phoneNo;
	double salary;
	void display() {
		System.out.println("Employee ID :"+id);
		System.out.println("Employee name :"+name);
		System.out.println("Employee PhoneNumber :"+phoneNo);
		System.out.println("Employee salary :"+salary);
	}


		
	}


