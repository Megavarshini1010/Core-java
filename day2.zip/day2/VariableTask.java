package day2;

public class VariableTask{
	public static void main(String[] args) {
		byte myage = 21;
		System.out.println("byte :" + myage);
		short number = 24999;
		System.out.print("byte :" + number);
	int value = 2345677;
	System.out.print("integer :" + value);
	long mblnumber = 8347465883l;
	System.out.println("long :" + mblnumber);
	float point = 456.52f;
	System.out.println("Float Point :" + point);
	double add = 846.45789;
	System.out.println("double :" + add);
	char word = 'M';
	System.out.println("Char :" + word);
	boolean var = true;
	System.out.println("Booleantrue :" + var);
	boolean varf = false;
	System.out.println("booleanfalse :" + varf);
	String str = "I am mega";
	System.out.println("Hii..." + str);
	}
}
