package day3;

import java.util.Scanner;

public class Calculator {
public static void main(String[] args) {
	Scanner ab = new Scanner(System.in);
	System.out.println("Enter your ID number1:");
	int num1 = ab.nextInt();
	System.out.println("Enter your ID number2:");
	int num2 = ab.nextInt();
	
System.out.println("Addition:" + (num1+num2));
System.out.println("Sutraction:" + (num1-num2));
System.out.println("Multiplication:" + (num1*num2));
System.out.println("Division:" + (num1/num2));
System.out.println("Modulus:" + (num1%num2));
}
}
