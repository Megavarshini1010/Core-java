package day6;
import java.util.Scanner;
public class TrafficFineCalculator {
  public static void  main(String [] args) {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter vehicle type ( 2 for 2-Wheeler or 4 for 4-Wheeler :");
	  int vehicle = sc.nextInt();
	  
	  
	  if(vehicle == 2) {
		  System.out.println("Enter your speed:");
		  int speed = sc.nextInt();
		  System.out.println("Enter speed limit:");
		  int limit = sc.nextInt();
		  int extra_speed = speed - limit;
		  if(speed>=1 && speed<10) {
			  System.out.println("Fine:₹ 500");
		  }
			  else if(speed>=10 && speed<20) {
				  System.out.println("Fine:₹ 1000");
			  }
				  else{
					  System.out.println("Fine:₹ 2000");
				  }
			  }
	  else if(vehicle == 4) {
		  System.out.println("Enter your speed:");
		  int speed = sc.nextInt();
		  System.out.println("Enter speed limit:");
		  int limit = sc.nextInt();
		  int extra_speed = speed - limit;
		  if(speed>=1 && speed<10) {
			  System.out.println("Fine:₹ 1000");
		  }
			  else if(speed>=10 && speed<20) {
				  System.out.println("Fine:₹ 2000");
			  }
				  else{
					  System.out.println("Fine:₹ 3000");
				  }
			  }
	  else {
		  System.out.println("Enter the correct vehicle type")
		  
		  
		  
		  
		  
		  ;
	  }
	  }
		  }
		  
	  
  

