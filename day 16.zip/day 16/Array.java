//ArrayList methods in java
import java.util.ArrayList;
import java.util.Collections;
//main class
public class Array {
    public static void main(String[] args) {
        //arraylist creation in  the type integer;
        ArrayList<Integer> m1 = new ArrayList<Integer>();
        ArrayList<Integer> m2 = new ArrayList<Integer>();
        //add the values
         m1.add(34);
         m1.add(76);
         m1.add(88);
         m1.add(22);
         m1.add(34);
        System.out.println(m1);
        //add themvalues in particular index
        m1.add(2,56);
        System.out.println(m1);
        //add m1 values into m2 collection
        m2.addAll(m1);
        System.out.println(m2);
        //add m1 values in particular index in m2 
        m2.addAll(4,m1);
        System.out.println(m2);
        //add first and last index 
        m1.addFirst(12);
        m1.addLast(10);
        System.out.println(m1);
        //get methods
        m1.get(5);
        //get the class of the m1
        m1.getClass();
        //get first adn last value of m1 collection
        m1.getFirst();
        m1.getLast();
        System.out.println(m1);
        //get values using for loop;
        for(int i=0;i<m1.size();i++){
            System.out.println("Using For loop:"+m1.get(i));
        }
        //replace the value in particular index
        m2.set(3,44 );
        System.out.println(m2);
        //Remove the values
        m2.remove(3);
         m2.removeFirst();
        m2.removeLast();
        System.out.println(m2);
        //Check the size of m2
        System.out.println("size of m2:"+m2.size());
        //check the m2 is empty or not
        System.out.println( "Check m2 is Empty:"+m2.isEmpty());
        //check 34 value contains in m1 or not
        System.out.println("34"+m1.contains(34));
        //check contailall the values m2 in m1
        System.out.println(m1.containsAll(m2));
        //check the index of particular element
        System.out.println(m1.indexOf(34));
        //check the last element of the index
        System.out.println(m1.lastIndexOf(34));
        //clear entirely m1 values
        m1.clear();
        System.out.println(m1);
        //check m1 and m2 is equal
        System.out.println(m1.equals(m2));
         //For each loop
         //sort the values from ascending to decending order
          Collections.sort(m2);      
         //for each loop in arraylist
         for(int m3:m2){
            System.out.println("m3 ArrayList:"+m3);
        }
        }
}
