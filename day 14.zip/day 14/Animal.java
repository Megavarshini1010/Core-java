package day15;

public interface Animal {
	String category = "Living Being";
	static boolean isMammal(String animalName) {
		return animalName == "dog"|| animalName == "cat"||animalName == "humanName";
		
	}
	public default void speak() {
		System.out.println("animal is making a sound");
	}
	void move();
}

