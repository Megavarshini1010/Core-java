package day15;

public class Bird implements Animal {

	@Override
	public void move() {
		System.out.println("The Bird Flies in the sky");
		
	}
	public void speak() {
		System.out.println("The bird says: Chrip Chirp");
	}
	

}
