package day15;

public class TestClass  {
	public static void main(String[] args) {
		Dog d = new Dog();
		Bird b = new Bird();
		d.speak();
		d.move();
		b.speak();
		b.move();
		System.out.println("Dog is a Mammel : "+Animal.isMammal("dog"));
		System.out.println("cat is a Mammel : "+Animal.isMammal("cat"));
		System.out.println(Animal.category);
		
	}
	

}
