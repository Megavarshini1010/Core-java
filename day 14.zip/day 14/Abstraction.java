package day15;
abstract  class claculator{
	abstract void add(int a , int b);
	abstract void sub();
	abstract void mul();
}
public class Abstraction extends claculator {
	void add(int a,int b) {
		System.out.println("Add : "+(a+b));
	}
	void sub() {
		System.out.println("Sub : "+(50-20));
	}
	void mul() {
		System.out.println("Mul : "+(10*20));
	}
	public static void main(String[] args) {
		Abstraction abs = new Abstraction();
		abs.add(10,20);
		abs.sub();
		abs.mul();
		
	}
 
}
