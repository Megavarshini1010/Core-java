package day9;

public class WhileLoop {
	public static void main(String[] args) {
		boolean istrue=true;
		while(true) {
			System.out.println("Hello");
		}
		
	}

}
