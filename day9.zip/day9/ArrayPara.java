package day9;

public class ArrayPara {
	public static void main(String[] args) {
		String a ="A paragraph is a distinct unit of writing, typically composed of multiple sentences, that focuses on a single idea or topic. It serves to organize and structure written content, making it easier for readers to follow the author's train of thought";
	    int count=0;
	    char[]letters=a.toCharArray();
	    for(char ref:letters) {
	    	if(ref=='i');{
	    		count++;
	    	}
	    }
	  System.out.println("count of i in a paragragh:"+count);	
	}

}
