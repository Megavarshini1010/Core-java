package day9;

public class ArrEx {
	public static void main(String[] args) {
		String a[]=new String[3];
		a[0]="jaya";
		a[1]="mega";
		a[2]="priya";
		for(int i=0;i<a.length;i++) {
		if(a[i]=="jaya") {
			a[i]="moni";
		}
		for(String ref:a) {
			System.out.println(ref);
		}
		}
		
		
		
		
	}

}
