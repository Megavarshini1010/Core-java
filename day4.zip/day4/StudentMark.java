package day4;

import java.util.Scanner;

public class StudentMark {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your Mark:");
		int mark = input.nextInt() ;
		if(mark>=35) {
			System.out.println("You are Pass the exam");
		}
		else if(mark <0 && mark>100){ 
		System.out.println("Invalid mark");
		}
		else {
			System.out.println("You are fail the exam");
		}
		
	}
}
